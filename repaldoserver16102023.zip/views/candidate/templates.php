<div class="content-wrapper">
    <div class="container mt-5">
        <div class="content pt-5">
            <div class="container-fluid">
                <h1>Selecciona una Plantilla de CV</h1>
                <div class="row">
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="<?= base_url ?>dist/img/Curriculumplantilla-Ejemplo.jpg" class="card-img-top" alt="Plantilla 1">
                            <div class="card-body">
                                <h5 class="card-title">Plantilla 1</h5>
                                <p class="card-text">Descripción de la plantilla 1.</p>
                                <a href="cv_plantilla1.pdf" class="btn btn-primary">Seleccionar</a>
                            </div>
                        </div>
                    </div>
                    <!-- Plantilla 1 -->
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="<?= base_url ?>dist/img/Resume1.jpg" class="card-img-top" alt="Plantilla 1">
                            <div class="card-body">
                                <h5 class="card-title">Plantilla 1</h5>
                                <p class="card-text">Descripción de la plantilla 1.</p>
                                <a href="cv_plantilla1.pdf" class="btn btn-primary">Seleccionar</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="<?= base_url ?>dist/img/Resume2.jpg" class="card-img-top" alt="Plantilla 2">
                            <div class="card-body">
                                <h5 class="card-title">Plantilla 2</h5>
                                <p class="card-text">Descripción de la plantilla 2.</p>
                                <a href="cv_plantilla2.pdf" class="btn btn-primary">Seleccionar</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="<?= base_url ?>dist/img/Resume3.jpg" class="card-img-top" alt="Plantilla 2">
                            <div class="card-body">
                                <h5 class="card-title">Plantilla 2</h5>
                                <p class="card-text">Descripción de la plantilla 2.</p>
                                <a href="cv_plantilla2.pdf" class="btn btn-primary">Seleccionar</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="<?= base_url ?>dist/img/Resume5.jpg" class="card-img-top" alt="Plantilla 2">
                            <div class="card-body">
                                <h5 class="card-title">Plantilla 2</h5>
                                <p class="card-text">Descripción de la plantilla 2.</p>
                                <a href="cv_plantilla2.pdf" class="btn btn-primary">Seleccionar</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="<?= base_url ?>dist/img/Resume6.jpg" class="card-img-top" alt="Plantilla 2">
                            <div class="card-body">
                                <h5 class="card-title">Plantilla 2</h5>
                                <p class="card-text">Descripción de la plantilla 2.</p>
                                <a href="cv_plantilla2.pdf" class="btn btn-primary">Seleccionar</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="<?= base_url ?>dist/img/Resume7.jpg" class="card-img-top" alt="Plantilla 2">
                            <div class="card-body">
                                <h5 class="card-title">Plantilla 2</h5>
                                <p class="card-text">Descripción de la plantilla 2.</p>
                                <a href="cv_plantilla2.pdf" class="btn btn-primary">Seleccionar</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="<?= base_url ?>dist/img/Resume8.jpg" class="card-img-top" alt="Plantilla 2">
                            <div class="card-body">
                                <h5 class="card-title">Plantilla 2</h5>
                                <p class="card-text">Descripción de la plantilla 2.</p>
                                <a href="cv_plantilla2.pdf" class="btn btn-primary">Seleccionar</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="<?= base_url ?>dist/img/Resume9.jpg" class="card-img-top" alt="Plantilla 2">
                            <div class="card-body">
                                <h5 class="card-title">Plantilla 2</h5>
                                <p class="card-text">Descripción de la plantilla 2.</p>
                                <a href="cv_plantilla2.pdf" class="btn btn-primary">Seleccionar</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="<?= base_url ?>dist/img/Resume10.jpg" class="card-img-top" alt="Plantilla 2">
                            <div class="card-body">
                                <h5 class="card-title">Plantilla 2</h5>
                                <p class="card-text">Descripción de la plantilla 2.</p>
                                <a href="cv_plantilla2.pdf" class="btn btn-primary">Seleccionar</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="<?= base_url ?>dist/img/Resume11.jpg" class="card-img-top" alt="Plantilla 2">
                            <div class="card-body">
                                <h5 class="card-title">Plantilla 2</h5>
                                <p class="card-text">Descripción de la plantilla 2.</p>
                                <a href="cv_plantilla2.pdf" class="btn btn-primary">Seleccionar</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="<?= base_url ?>dist/img/Resume12.jpg" class="card-img-top" alt="Plantilla 2">
                            <div class="card-body">
                                <h5 class="card-title">Plantilla 2</h5>
                                <p class="card-text">Descripción de la plantilla 2.</p>
                                <a href="cv_plantilla2.pdf" class="btn btn-primary">Seleccionar</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="<?= base_url ?>dist/img/Resume13.jpg" class="card-img-top" alt="Plantilla 2">
                            <div class="card-body">
                                <h5 class="card-title">Plantilla 2</h5>
                                <p class="card-text">Descripción de la plantilla 2.</p>
                                <a href="cv_plantilla2.pdf" class="btn btn-primary">Seleccionar</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="<?= base_url ?>dist/img/Resume14.jpg" class="card-img-top" alt="Plantilla 2">
                            <div class="card-body">
                                <h5 class="card-title">Plantilla 2</h5>
                                <p class="card-text">Descripción de la plantilla 2.</p>
                                <a href="cv_plantilla2.pdf" class="btn btn-primary">Seleccionar</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="<?= base_url ?>dist/img/Resume15.jpg" class="card-img-top" alt="Plantilla 2">
                            <div class="card-body">
                                <h5 class="card-title">Plantilla 2</h5>
                                <p class="card-text">Descripción de la plantilla 2.</p>
                                <a href="cv_plantilla2.pdf" class="btn btn-primary">Seleccionar</a>
                            </div>
                        </div>
                    </div>
                    <!-- Agrega más plantillas aquí -->
                </div>
            </div>
        </div>
    </div>
</div>