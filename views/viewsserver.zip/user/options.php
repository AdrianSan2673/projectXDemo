<p class="login-box-msg text-white"><b>¿Qué deseas hacer?</b></p>

<div class="row mb-3">
<!-- /.col -->
    <div class="col-12">
        <a href="<?=base_url?>bolsa/vacantes" class="btn btn-success btn-block">Conocer y postularte a nuestras vacantes</a>
    </div>
<!-- /.col -->
</div>
<div class="row mb-3">
<!-- /.col -->
    <div class="col-12">
        <a href="<?=base_url?>usuario/registrar" class="btn btn-info btn-block text-white">Subir o diseñar tu CV de manera profesional</a>
    </div>
<!-- /.col -->
</div>
<div class="row">
<!-- /.col -->
    <div class="col-12">
        <a href="<?=base_url?>usuario/index" class="btn btn-orange btn-block text-white">Iniciar sesión</a>
    </div>
<!-- /.col -->
</div>

