    <div class="content-wrapper">
      <div class="container">
      	<div class="row mb-2">
          <div class="col-sm-12">
            <div class="alert alert-orange mt-5">
                <h4>Vacante no disponible</h4>
            </div>       
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
	          <div class="card">
	              <div class="card-body">
	                  <h6>Lo sentimos, esta vacante ya no está disponible.</h6>
					  
					  <a href="<?=base_url?>bolsa/vacantes" class=" btn btn-success mt-5">Volver al listado de vacantes</a>
	              </div>
	          </div>
          </div>
        </div>
      </div>
    </div>