<div class="container">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-12">
            <div class="alert alert-orange">
                <h4>Error</h4>
            </div>         
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    
    <section class="content">
        <div class="error-page">
            <h2 class="headline text-orange"> 404</h2>

            <div class="error-content">
                <h3><i class="fas fa-exclamation-triangle text-orange"></i> Lo sentimos, esta página no existe</h3>

                <p>
                    No se encontró la página que estabas buscando
                </p>

            </div>
            <!-- /.error-content -->
        </div>      
    </section>  
</div>
<script>
    setTimeout(() => {
        window.location.href = "http://rrhh-ingenia.com/reclutamiento"
    }, 5000);
</script>
